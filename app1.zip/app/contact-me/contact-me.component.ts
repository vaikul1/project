import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-contact-me',
  templateUrl: './contact-me.component.html',
  styleUrls: ['./contact-me.component.css']
})
export class ContactMeComponent implements OnInit {
  @Input() firstname:string="";
  @Input() surname:string="";
  @Input() email:string="";
  @Input() phone:string="";
  @Input() message:string="";
  constructor() {
    
   }

  ngOnInit() {
  }

}
