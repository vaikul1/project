import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-biography',
  templateUrl: './personal-biography.component.html',
  styleUrls: ['./personal-biography.component.css']
})
export class PersonalBiographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
