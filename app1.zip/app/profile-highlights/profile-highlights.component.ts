import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-highlights',
  templateUrl: './profile-highlights.component.html',
  styleUrls: ['./profile-highlights.component.css']
})
export class ProfileHighlightsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
