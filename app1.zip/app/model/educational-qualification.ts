export interface EducationalQualification {
    id:number;
    qualification:string;
    center:string;
    university:string;
    yop:string;
}
