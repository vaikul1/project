import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms'; 
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { ProfileHighlightsComponent } from './profile-highlights/profile-highlights.component';
import { ProjectsComponent } from './projects/projects.component';
import { ExperienceComponent } from './experience/experience.component';
import { PersonalBiographyComponent } from './personal-biography/personal-biography.component';
import { ContactMeComponent } from './contact-me/contact-me.component';
import { EducationalQualificationComponent } from './educational-qualification/educational-qualification.component';
import { NgbdModalBasic } from './modal-basic';


const appRoutes: Routes = [
  {
    path: '',
    redirectTo: "/profile-highlights",
    pathMatch: 'full'
  },
  { path: 'profile-highlights', component: ProfileHighlightsComponent },
  { path: 'projects',      component: ProjectsComponent },
  { path: 'experience',      component: ExperienceComponent },
  { path: 'educational-qualification',      component: EducationalQualificationComponent },
  { path: 'personal-biography',      component: PersonalBiographyComponent },
  { path: 'contact-me',      component: ContactMeComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    ProfileHighlightsComponent,
    ProjectsComponent,
    ExperienceComponent,
    PersonalBiographyComponent,
    ContactMeComponent,
    EducationalQualificationComponent,
    NgbdModalBasic
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    ),
    NgbModule.forRoot(),
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
