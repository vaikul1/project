import { Injectable }      from '@angular/core';
import {IEmployee} from './employee';
@Injectable()
export class EmployeeService{
    getAllEmployee():IEmployee[] 
{ return  [
           { empId: 1001, empName: "Rahul", empSalary: 15000, empDepartment: "JAVA" },
           { empId: 1002, empName: "Vikash", empSalary: 16000, empDepartment: "JAVA" },
           { empId: 1003, empName: "Shital", empSalary: 17000, empDepartment: ".NET" },
           { empId: 1004, empName: "VISHAL", empSalary: 18000, empDepartment: "BI" },
           { empId: 1005, empName: "Amal", empSalary: 19000, empDepartment: "IMS" },
           { empId: 1006, empName: "Vandana", empSalary: 19000, empDepartment: "SAP" },
           { empId: 1007, empName: "Vaishali", empSalary: 19000, empDepartment: "Mainframe" },
       ];
    }
}